import { createFloatingIcon } from './ui/FloatingIcon';

// Initialize floating icon when content script loads
createFloatingIcon();
